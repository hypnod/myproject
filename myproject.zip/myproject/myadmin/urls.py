"""myproject URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,re_path

from myadmin.views import index, users

urlpatterns = [
    path('', index.index, name="myadmin_index"), # 后台首页
    # 会员信息管理路由
    re_path(r'^users$', users.index, name="myadmin_users_index"),
    re_path(r'^users/add$', users.add, name="myadmin_users_add"),
    re_path(r'^users/insert$', users.insert, name="myadmin_users_insert"),
    re_path(r'^users/del/(?P<uid>[0-9]+)$', users.delete, name="myadmin_users_del"),
    re_path(r'^users/edit/(?P<uid>[0-9]+)$', users.edit, name="myadmin_users_edit"),
    re_path(r'^users/update/(?P<uid>[0-9]+)$', users.update, name="myadmin_users_update"),
      # 后台管理员路由
    re_path(r'^login$', index.login, name="myadmin_login"),
    re_path(r'^dologin$', index.dologin, name="myadmin_dologin"),
    re_path(r'^logout$', index.logout, name="myadmin_logout"),
    re_path(r'^verify$', index.verify, name="myadmin_verify"), #验证码
]
