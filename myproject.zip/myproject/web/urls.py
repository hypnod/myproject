"""myproject URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, re_path

from web.views import index

urlpatterns = [
    path('', index.index, name="web_index"),
    re_path('^menu', index.menu, name='web_menu'),
    re_path('^demo1$', index.demo1, name='web_demo1'),
    re_path('^uploadfile$', index.upload, name='upload_file'), # 上传
    re_path(r'^file/(?P<code>\d+)/$', index.get, name='get_file'),
    # re_path('^downloadfile$', index.downloadf, name='downloadf') # 下载
    re_path(r'ueditor$', index.ueditor, name="ueditor"),

    # 会员及个人中心等路由配置
    re_path(r'^login$', index.login, name="login"),
    re_path(r'^dologin$', index.dologin, name="dologin"),
    re_path(r'^logout$', index.logout, name="logout"),
    # 会员注册配置
    re_path(r'^register$', index.register, name="register"),            
    re_path(r'^doregister$', index.doregister, name="doregister"),  

]
