from django.shortcuts import render
from django.views.generic import View

from django.views.decorators.csrf import csrf_exempt
from common.models import Upload
from django.http import HttpResponsePermanentRedirect, HttpResponse
import random
import string
import datetime
import json

from common.models import Users
from django.shortcuts import redirect
from django.urls import reverse
# Create your views here.

#前台首页
def index(request):
    return render(request, "web/login.html")
def demo1(request):
    return render(request, "web/demo1.html")
def menu(request):
    return render(request, 'web/index.html')
@csrf_exempt
def upload(request):# post请求
    ob = Upload()
    if request.method == "POST":    # 请求方法为POST时，进行处理  
        file = request.FILES.get("file", None) #获取文件
        print(file)
        if not file:  
            return HttpResponse("no files for upload!")
        name = file.name #获取文件名
        if name in ob.name:
            return HttpResponse('文件已存在！') 
        
        # size = int(file.size)#获取文件大小
        with open('static/file/'+name,'wb+')as f : #写文件到static/files
            for chunk in file.chunks():      # 分块写入文件  
                f.write(chunk)  
        code = ''.join(random.sample(string.digits, 8))#生成随机八位的code
        u = Upload(
            path = 'static/file/'+name,
            name=name,
            # filesize=size,
            code = code,
            datatime = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        )
        u.save()#存储数据库
        return HttpResponsePermanentRedirect("/file/"+code)
    else:
        return HttpResponse('upload filed!')
        #使用 HttpResponsePermanentRedirect 重定向到展示文件的页面.这里的 code 唯一标示一个文件。

def get(request, code): #支持get请求,并且可接受一个参数，这里的code 需要和 配置路由的 code 保持一致
        u = Upload.objects.filter(code=str(code)) #ORM 模型的查找
        if u :#如果u 有内容,u的访问次数+1，否则返回给前端的内容也是空的.
            for i in u :
                i.downloadcount +=1 #每次访问,访问次数+1
                i.save() #保存结果
        return render(request,'web/content.html',{"content":u})#返回页面,其中content是#我们传给前端页面的内容
        #content.html在template文件夹中。

# ==============前台会员登录====================
def login(request):
    '''员工登录表单'''
    return render(request,'web/login.html')

def dologin(request):
    '''员工执行登录'''
    # 校验验证码
    verifycode = request.session['verifycode']
    code = request.POST['code']
    if verifycode != code:
        context = {'info':'验证码错误！'}
        return render(request,"web/login.html",context)
    try:
        #根据账号获取登录者信息
        user = Users.objects.get(username=request.POST['username'])
        #判断当前用户是否是禁用用户
        if user.level == 0 or user.level == 1:
            # 验证密码
            import hashlib
            m = hashlib.md5() 
            m.update(bytes(request.POST['password'],encoding="utf8"))
            if user.password == m.hexdigest():
                # 此处登录成功，将当前登录信息放入到session中，并跳转页面
                request.session['vipuser'] = user.toDict()
                return redirect(reverse('web_menu'))
            else:
                context = {'info':'登录密码错误！'}
        else:
            context = {'info':'此用户为非法用户！'}
    except:
        context = {'info':'登录账号错误！'}
    return render(request,"web/login.html", context)

def logout(request):
    '''会员退出'''
    # 清除登录的session信息
    del request.session['vipuser']
    # 跳转登录页面（url地址改变）
    return redirect(reverse('login'))

def register(request):
    '''会员注册表单'''
    return render(request,'web/register.html')

def doregister(request):
    '''执行会员注册'''
    try:
        #判断登录账号是否有重复
        if Users.objects.filter(username=request.POST['username']).count() > 0:
            context = {'info':'登录账号已经被注册！'}
        else:
            if request.POST['password'] != request.POST['repassword']:
                context = {'info':'两次输入密码不一致！'}
            else:
                #执行添加员工信息
                ob = Users()
                ob.username = request.POST['username']
                import hashlib
                m = hashlib.md5() 
                m.update(bytes(request.POST['password'],encoding="utf8"))
                ob.password = m.hexdigest()
                ob.addtime = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                ob.save()
                # 此处注册和登录成功，将当前登录信息放入到session中，并跳转到首页
                request.session['vipuser'] = ob.toDict()
                return redirect(reverse('login'))
    except Exception as err:
        print(err)
        context = {'info':'注册账号失败！'}
    return render(request,"web/register.html",context)

def ueditor(request):
    # 记事本
    return render(request, "web/ueditor.html")
